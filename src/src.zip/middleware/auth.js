const jwt = require('jsonwebtoken');

const verifyToken = (req, res, next) => {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
        return res.status(401).json({
            success:false,
            message:'Token Missing'
        });
    }

    // const token = authHeader.split(' ')[1];
    try {
        const decoded = jwt.verify(authHeader,process.env.JWT_SECRET);
        // req.memberId = decoded.memberId;
        next();
    } catch(err){
        return res.status(401).json({
            success:false,
            message:'Invalid Token'
        });

    }
};

module.exports = {verifyToken};